# Timing with OpenMP

Use `omp_get_wtime()` before and after your function calls to measure execution time.