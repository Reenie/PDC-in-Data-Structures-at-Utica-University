# OpenMP Setup Guide

Use `g++ -fopenmp` to compile C++ programs using OpenMP.