# Assignment 1: Sorting Exam Scores

## Scenario
You are helping a university department sort thousands of exam scores. Optimize this task using parallel Merge Sort.

## Objectives
- Understand and implement merge sort.
- Learn OpenMP task parallelism.

## Tasks
1. Write a sequential merge sort.
2. Add OpenMP tasks to parallelize the recursive calls.
3. Measure performance using `omp_get_wtime()`.

## Submission
- Upload both versions to [OnlineGDB](https://www.onlinegdb.com/online_c++_compiler) and submit sharable links.
