# Assignment: Friend Suggestion in Social Network

## Problem Context
Simulate 'friend of a friend' suggestions using graph BFS traversal.

## Learning Objectives
- Implement BFS.
- Explore parallelism at each level.

## Tasks
1. Write BFS using adjacency list.
2. Try parallelizing neighbor loops.

## Submission
Submit OnlineGDB link of both versions.