# Assignment: Undo History Manager

## Problem Context
Simulate collaborative editing where multiple users push/pop from a shared undo stack.

## Learning Objectives
- Implement stack.
- Handle concurrency with OpenMP.

## Tasks
1. Implement stack in C++.
2. Simulate parallel push/pop using OpenMP.

## Submission
Submit OnlineGDB link of both versions.