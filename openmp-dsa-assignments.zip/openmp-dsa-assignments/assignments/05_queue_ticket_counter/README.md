# Assignment: Ticket Counter Queue

## Problem Context
Visitors queue up for tickets served by multiple counters. Simulate this behavior using circular queue and OpenMP.

## Learning Objectives
- Implement circular queue.
- Use parallel sections for enqueue/dequeue.

## Tasks
1. Write basic queue.
2. Use OpenMP to simulate producers/consumers.

## Submission
Submit OnlineGDB link of both versions.