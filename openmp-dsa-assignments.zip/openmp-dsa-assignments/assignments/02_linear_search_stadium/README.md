# Assignment: Lost & Found in Stadium

## Problem Context
You manage a digital lost-and-found system for a stadium. You need to quickly search item IDs in a large dataset.

## Learning Objectives
- Implement linear search.
- Use OpenMP `parallel for` for faster searching.

## Tasks
1. Implement sequential linear search.
2. Parallelize the search using OpenMP.
3. Measure speedup for large arrays.

## Submission
Submit OnlineGDB link of both versions.